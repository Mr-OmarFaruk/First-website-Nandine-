$(document).ready(function($){
	"use strict";

	// WOW Js Active
	new WOW().init();

	// ---- Active
    $(".owl").owlCarousel();
    // Owl Next Privew Change
    //$( ".owl-prev").html('<i class="fa screenshort-arow fa-chevron-left"></i>');
    //$( ".owl-next").html('<i class="fa screenshort-arow fa-chevron-right"></i>');

    /*team*/
    $('.owl-carousel-team').owlCarousel({
	    loop:true,
	    margin:20,
	    nav:false,
	    items:4,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:3
	        },
	        1000:{
	            items:4
	        }
	    }
	});

	/*testimonial*/
    $('.owl-carousel-testomonila').owlCarousel({
	    loop:true,
	    margin:10,
	    nav:false,
	    items:1
	});



    /*magnificPopup*/
    $('#youtube-video').magnificPopup({
    	type:'iframe',
    	iframe: {
		  patterns: {
		    youtube: {
		      index: 'youtube.com/', 
		      id: 'v=',

		      src: 'http://www.youtube.com/embed/%id%?autoplay=1'},
		    
		  },

		  srcAction: 'iframe_src',
		}
		});

    /*skillbar*/
    $('.skillbar').skillBars({
	  // options here
	});

    /*counter*/
    $('.counter-number').each(function () {
	    $(this).prop('Counter',0).animate({
	        Counter: $(this).text()
	    }, {
	        duration: 3000,
	        easing: 'swing',
	        step: function (now) {
	            $(this).text(Math.ceil(now));
	        }
	    });
	});

	/*protfolio*/
	var mixer = mixitup('.protfolio-content');

	/*photo-magnification*/
	$('.image-link').magnificPopup({type:'image'});

	/*scrollup*/
	$.scrollUp({
    scrollName: 'scrollUp', // Element ID
    topDistance: '300', // Distance from top before showing element (px)
    topSpeed: 500, // Speed back to top (ms)
    animation: 'fade', // Fade, slide, none
    animationInSpeed: 300, // Animation in speed (ms)
    animationOutSpeed: 300, // Animation out speed (ms)
    scrollText: 'Go to top', // Text for element
    activeOverlay: false, // Set CSS color to display scrollUp active point, e.g '#00FFFF'
  });


	/*$.scrollUp({
                            animation: 'fade',
                            activeOverlay: '#00FFFF',
                            scrollImg: {
                                active: true,
                                type: 'background',
                                src: '../img/top.png'
                            }
                        });*/
	
}(jQuery));